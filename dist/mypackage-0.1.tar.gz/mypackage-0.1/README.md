# mypackage
This library was created as example of how to public your own Python packge.

## building this package locally
`python setup.py sdist`

## installing this package from GitHub
`pip install git+https://github.com/i-ambale`

## updating this package from GitHub
`pip install --upgrade git+https://github.com/i-ambale`